/*
 * FileHandler.java
 *
 * Copyright (C) 2007 Irving Bunton
 * http://code.google.com/p/jlogmicro/source
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
// Expand to define CLDC define
//#define DCLDCV10
// Expand to define DJSR75 define
//#define DNOJSR75
// Expand to define logging define
//#define DLOGGING
//#ifdef DLOGGING
//#ifdef DJSR75
//@package net.sf.jlogmicro.util.logging;
//@
//@import java.util.Date;
//@import java.util.Vector;
//@import java.util.Hashtable;
//@import java.io.DataOutputStream;
//@import java.io.IOException;
//@import javax.microedition.io.file.FileConnection;
//@import javax.microedition.io.Connector;
//@
//@import net.sf.jlogmicro.util.logging.Handler;
//@import net.sf.jlogmicro.util.logging.LogRecord;
//@
//@public class FileHandler extends BufferedHandler {
//@
//@	private FileConnection fc = null;
//@
//@	public FileHandler() {
//@	}
//@
//@	public Object openView(boolean append) {
//@		try {
//@			if (view == null) {
//@				fc = (FileConnection)Connector.open( name,
//@						Connector.READ | Connector.WRITE );
//@				if (!fc.exists()) {
//@					fc.create();
//@				}
//@				if (append) {
//@					view = new DataOutputStream(fc.openOutputStream(
//@								fc.fileSize()));
//@				} else {
//@					view = fc.openDataOutputStream();
//@				}
//@			}
//@			return view;
//@		} catch (Throwable e) {
//@			System.err.println("File open error " + name + "," +
//@					e.getMessage() + "," + e.getClass().getName());
//@			e.printStackTrace();
//@		}
//@		return view;
//@	}
//@
//@	public void removeView() {
//@		try {
//@			if (view == null) {
//@				openView(false);
//@			}
//@			((DataOutputStream)view).close();
//@			fc.delete();
//@			closeView();
//@		} catch (Throwable e) {
//@			System.err.println("File open error " + name + "," +
//@					e.getMessage() + "," + e.getClass().getName());
//@			e.printStackTrace();
//@		}
//@	}
//@
//@    public void closeView() {
//@		try {
//@			if (view != null) {
//@				((DataOutputStream)view).close();
//@			}
//@			if (fc != null) {
//@				fc.close();
//@			}
//@		} catch (IOException e) {
//@			e.printStackTrace();
//@		} finally {
//@			view = null;
//@			fc = null;
//@		}
//@	}
//@
//@	public void publish(LogRecord record) {
//@		synchronized (this) {
//@			/* FIX
//@			int fsize = form.size();
//@			if ((maxEntries != 0) && (fsize >= maxEntries)) {
//@				form.delete(fsize - 1);
//@			}
//@			*/
//@			try {
//@				if (view == null) {
//@					openView(true);
//@				}
//@				String fmtRec = formatter.format(record);
//@				((DataOutputStream)view).writeUTF(formatter.format(record) + "\n");
//@			} catch (OutOfMemoryError e) {
//@				record.setMessage("Out of memory.  Cannot log message.");
//@				try {
//@					((DataOutputStream)view).writeUTF(
//@						formatter.format(record) + "\n");
//@				} catch (Throwable e2) {
//@					System.err.println(
//@							"File write error from out of memory " +
//@							name + "," +
//@							e2.getMessage() + "," + e2.getClass().getName());
//@					e.printStackTrace();
//@				}
//@			} catch (Throwable e) {
//@				System.err.println("File write error " + name + "," +
//@						e.getMessage() + "," + e.getClass().getName());
//@				e.printStackTrace();
//@			}
//@		}
//@	}
//@
//@}
//#endif
//#endif

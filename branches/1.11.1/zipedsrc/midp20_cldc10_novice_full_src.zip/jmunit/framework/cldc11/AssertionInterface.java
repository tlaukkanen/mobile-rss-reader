/*
 * Assertion.java
 *  
 * Copyright 2006 Brunno Silva
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Expand to define MIDP define
//#define DCLDCV10
// Expand to define JMUNITPLUS define
//#define DNOJMTESTPLUS

//#ifdef DJMTESTPLUS
//@package jmunit.framework.cldc11;
//@
//@/**
//@ * The root class for the test classes tree. It has all the basic assertions and
//@ * main methods used by the developers to create the tests.
//@ * 
//@ * @author Brunno Silva
//@ * @since JMUnit 1.0
//@ */
//@public interface AssertionInterface {
//@
//@	/**
//@	 * Assert if the object is null. If it is, nothing happens. Otherwise, it
//@	 * throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param object
//@	 *            the object to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNull(String test, Object object)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the object isn't null. If it isn't, nothing happens. Otherwise,
//@	 * it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param object
//@	 *            the object to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotNull(String test, Object object)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the boolean expression is true. If it is, nothing happens.
//@	 * Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expression
//@	 *            the boolean expression to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertTrue(String test, boolean expression)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the boolean expression is false. If it is, nothing happens.
//@	 * Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expression
//@	 *            the boolean expression to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertFalse(String test, boolean expression)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected object and the actual object are the same. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertSame(String test, Object expected,
//@			Object actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected object and the actual object aren't the same. If
//@	 * they aren't, nothing happens. Otherwise, it throws a
//@	 * AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotSame(String test, Object expected,
//@			Object actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected object and the actual object are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(String test, Object expected,
//@			Object actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected object and the actual object aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(String test, Object expected,
//@			Object actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected boolean and the actual boolean are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the boolean that is correct.
//@	 * @param actual
//@	 *            the boolean that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(String test, boolean expected,
//@			boolean actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected boolean and the actual boolean aren't equal. If
//@	 * they aren't, nothing happens. Otherwise, it throws a
//@	 * AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the boolean that is correct.
//@	 * @param actual
//@	 *            the boolean that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(String test, boolean expected,
//@			boolean actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected char and the actual char are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the char that is correct.
//@	 * @param actual
//@	 *            the char that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(String test, char expected,
//@			char actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected char and the actual char aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the char that is correct.
//@	 * @param actual
//@	 *            the char that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(String test, char expected,
//@			char actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected int and the actual int are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the int that is correct.
//@	 * @param actual
//@	 *            the int that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(String test, int expected, int actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected int and the actual int aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the int that is correct.
//@	 * @param actual
//@	 *            the int that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(String test, int expected,
//@			int actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected byte and the actual byte are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the byte that is correct.
//@	 * @param actual
//@	 *            the byte that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(String test, byte expected,
//@			byte actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected byte and the actual byte aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the byte that is correct.
//@	 * @param actual
//@	 *            the byte that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(String test, byte expected,
//@			byte actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected long and the actual long are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the long that is correct.
//@	 * @param actual
//@	 *            the long that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(String test, long expected,
//@			long actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected long and the actual long aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the long that is correct.
//@	 * @param actual
//@	 *            the long that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(String test, long expected,
//@			long actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected short and the actual short are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the short that is correct.
//@	 * @param actual
//@	 *            the short that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(String test, short expected,
//@			short actual) throws AssertionFailedException;
//@
	//#ifdef DCLDCV11
//@	/**
//@	 * Assert if the expected float and the actual float are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the float that is correct.
//@	 * @param actual
//@	 *            the float that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(String test, float expected,
//@			float actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected float and the actual float aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the float that is correct.
//@	 * @param actual
//@	 *            the float that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(String test, float expected,
//@			float actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected double and the actual double are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the double that is correct.
//@	 * @param actual
//@	 *            the double that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(String test, double expected,
//@			double actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected double and the actual double aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the double that is correct.
//@	 * @param actual
//@	 *            the double that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(String test, double expected,
//@			double actual) throws AssertionFailedException;
	//#endif
//@
//@	/**
//@	 * Assert if the expected short and the actual short aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the short that is correct.
//@	 * @param actual
//@	 *            the short that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(String test, short expected,
//@			short actual) throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the object is null. If it is, nothing happens. Otherwise, it
//@	 * throws a AssertionFailedException. It has a default String to identify
//@	 * itself.
//@	 * 
//@	 * @param object
//@	 *            the object to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNull(Object object)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the object isn't null. If it isn't, nothing happens. Otherwise,
//@	 * it throws a AssertionFailedException. It has a default String to identify
//@	 * itself.
//@	 * 
//@	 * @param object
//@	 *            the object to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotNull(Object object)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the boolean expression is true. If it is, nothing happens.
//@	 * Otherwise, it throws a AssertionFailedException. It has a default String
//@	 * to identify itself.
//@	 * 
//@	 * @param expression
//@	 *            the boolean expression to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertTrue(boolean expression)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the boolean expression is false. If it is, nothing happens.
//@	 * Otherwise, it throws a AssertionFailedException. It has a default String
//@	 * to identify itself.
//@	 * 
//@	 * @param expression
//@	 *            the boolean expression to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertFalse(boolean expression)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected object and the actual object are the same. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
//@	 * has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertSame(Object expected, Object actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected object and the actual object aren't the same. If
//@	 * they aren't, nothing happens. Otherwise, it throws a
//@	 * AssertionFailedException. It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotSame(Object expected, Object actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected object and the actual object are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
//@	 * has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(Object expected, Object actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected object and the actual object aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(Object expected, Object actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected boolean and the actual boolean are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
//@	 * has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the boolean that is correct.
//@	 * @param actual
//@	 *            the boolean that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(boolean expected, boolean actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected boolean and the actual boolean aren't equal. If
//@	 * they aren't, nothing happens. Otherwise, it throws a
//@	 * AssertionFailedException. It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the boolean that is correct.
//@	 * @param actual
//@	 *            the boolean that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(boolean expected, boolean actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected char and the actual char are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the char that is correct.
//@	 * @param actual
//@	 *            the char that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(char expected, char actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected char and the actual char aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the char that is correct.
//@	 * @param actual
//@	 *            the char that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(char expected, char actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected int and the actual int are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the int that is correct.
//@	 * @param actual
//@	 *            the int that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(int expected, int actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected int and the actual int aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the int that is correct.
//@	 * @param actual
//@	 *            the int that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(int expected, int actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected byte and the actual byte are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the byte that is correct.
//@	 * @param actual
//@	 *            the byte that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(byte expected, byte actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected byte and the actual byte aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the byte that is correct.
//@	 * @param actual
//@	 *            the byte that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(byte expected, byte actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected long and the actual long are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the long that is correct.
//@	 * @param actual
//@	 *            the long that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(long expected, long actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected long and the actual long aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the long that is correct.
//@	 * @param actual
//@	 *            the long that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(long expected, long actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected short and the actual short are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the short that is correct.
//@	 * @param actual
//@	 *            the short that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(short expected, short actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected short and the actual short aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the short that is correct.
//@	 * @param actual
//@	 *            the short that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(short expected, short actual)
//@			throws AssertionFailedException;
//@
	//#ifdef DCLDCV11
//@	/**
//@	 * Assert if the expected float and the actual float are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the float that is correct.
//@	 * @param actual
//@	 *            the float that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(float expected, float actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected float and the actual float aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the float that is correct.
//@	 * @param actual
//@	 *            the float that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(float expected, float actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected double and the actual double are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
//@	 * has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the double that is correct.
//@	 * @param actual
//@	 *            the double that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertEquals(double expected, double actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * Assert if the expected double and the actual double aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the double that is correct.
//@	 * @param actual
//@	 *            the double that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	void assertNotEquals(double expected, double actual)
//@			throws AssertionFailedException;
	//#endif
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail(String test) throws AssertionFailedException;
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail(String test, short expected, short actual)
//@			throws AssertionFailedException;
//@
	//#ifdef DCLDCV11
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail(String test, float expected, float actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail(String test, double expected, double actual)
//@			throws AssertionFailedException;
	//#endif
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail(String test, long expected, long actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail(String test, byte expected, byte actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail(String test, int expected, int actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail(String test, char expected, char actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail(String test, boolean expected, boolean actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail(String test, Object expected, Object actual)
//@			throws AssertionFailedException;
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition.
//@	 * 
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	void fail() throws AssertionFailedException;
//@
//@}
//#endif

/*
 * TestRunnerMIDlet.java
 *  
 * Copyright 2008 C.A. Meijer
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/*
 * This was first modified on 2011/01/08
 */
// Expand to define JMUNITPLUS define
//#define DNOJMTESTPLUS
//#ifdef DJMTESTPLUS
//@package jmunit.framework.cldc11;
//@
//@import java.util.Date;
//@import java.util.Vector;
//@
//@/**
//@ * The TestRunnerMIDlet class runs a test immediately on launching of a MIDlet. The
//@ * MIDlet shuts down shortly after the tests finish. This class should be used
//@ * 
//@ * @author C.A. Meijer
//@ * @since JMUnit 1.1.
//@ */
//@public abstract class TestRunnerMIDlet
//@extends TestMIDlet
//@implements TestRunnerInterface
//@{
//@	/**
//@	 * Constructor.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	public TestRunnerMIDlet() {
//@		super();
//@	}
//@
//@	/**
//@	 * Constructor.
//@	 * 
//@	 * @param delay
//@	 *            The delay in milliseconds after which the MIDlet should close
//@	 *            down.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	public TestRunnerMIDlet(TestRunner testRunner) {
//@		super(testRunner);
//@	}
//@
//@	/**
//@	 * We override the doStart method to run the tests immediately.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	public void doStart() {
//@		((TestRunner)testMain).doStart();
//@	}
//@
//@	/**
//@	 * Counts the number of tests.
//@	 * 
//@	 * @return The number of test cases.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	public int countTestCases() {
//@		return ((TestRunner)testMain).countTestCases();
//@	}
//@
//@	/**
//@	 * Runs and reports the tests.
//@	 * 
//@	 * @param results
//@	 *            The TestResult where the results are gathered.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	public void run(TestResult results) {
//@		((TestRunner)testMain).run(results);
//@	}
//@
//@    public void setTestRunner(TestRunner testRunner) {
//@        super.testMain = testRunner;
//@    }
//@
//@    public TestRunner getTestRunner() {
//@        return ((TestRunner)testMain);
//@    }
//@
//@}
//#endif

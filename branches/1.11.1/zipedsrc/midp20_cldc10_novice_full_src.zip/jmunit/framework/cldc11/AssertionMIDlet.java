/*
 * AssertionMIDlet.java
 *  
 * Copyright 2006 Brunno Silva
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Expand to define CLDC define
//#define DCLDCV10
// Expand to define JMTESTPLUS define
//#define DNOJMTESTPLUS
// Expand to define logging define
//#define DLOGGING
//#ifdef DJMTESTPLUS
//@package jmunit.framework.cldc11;
//@
//@import javax.microedition.midlet.MIDletStateChangeException;
//@import javax.microedition.midlet.MIDlet;
//@
//#ifdef DLOGGING
//@import net.sf.jlogmicro.util.logging.Logger;
//@import net.sf.jlogmicro.util.logging.LogManager;
//@import net.sf.jlogmicro.util.logging.Level;
//#endif
//@
//@/**
//@ * The AssertionMIDlet is a abstract class that has the main implementation to create a
//@ * executing test class or a utility class to execute others. The MIDlet methods
//@ * as startApp are localized here.
//@ * 
//@ * @author Brunno Silva
//@ * @since JMUnit 1.0
//@ */
//@public abstract class AssertionMIDlet
//@extends MIDlet
//@implements AssertionInterface
//@{
//@	/**
//@	 * The Assertion used to implement AssertionInterface.
//@	 */
//@	protected AssertionInterface assertion;
//@
	//#ifdef DLOGGING
//@    protected boolean fineLoggable;
//@    protected boolean finestLoggable;
//@    protected Logger logger;
	//#endif
//@
//@	protected AssertionMIDlet() {
		//#ifdef DLOGGING
//@		LogManager logManager = LogManager.getLogManager();
//@		logManager.readConfiguration(this);
//@		logger = Logger.getLogger("AssertionMIDlet");
//@		logger.info("AssertionMIDlet started.");
//@		fineLoggable = logger.isLoggable(Level.FINE);
//@		logger.fine("obj,fineLoggable=" + this + "," + fineLoggable);
//@		finestLoggable = logger.isLoggable(Level.FINEST);
//@		logger.fine("obj,finestLoggable=" + this + "," + finestLoggable);
		//#endif
//@	}
//@
//@	/**
//@	 * Assert if the object is null. If it is, nothing happens. Otherwise, it
//@	 * throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param object
//@	 *            the object to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNull(String test, Object object)
//@		throws AssertionFailedException {
//@			assertion.assertNull(test, object);
//@	}
//@
//@	/**
//@	 * Assert if the object isn't null. If it isn't, nothing happens. Otherwise,
//@	 * it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param object
//@	 *            the object to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotNull(String test, Object object)
//@		throws AssertionFailedException {
//@			assertion.assertNotNull(test, object);
//@	}
//@
//@	/**
//@	 * Assert if the boolean expression is true. If it is, nothing happens.
//@	 * Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expression
//@	 *            the boolean expression to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertTrue(String test, boolean expression)
//@	throws AssertionFailedException {
//@		assertion.assertTrue(test, expression);
//@	}
//@
//@	/**
//@	 * Assert if the boolean expression is false. If it is, nothing happens.
//@	 * Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expression
//@	 *            the boolean expression to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertFalse(String test, boolean expression)
//@	throws AssertionFailedException {
//@		assertion.assertFalse(test, expression);
//@	}
//@
//@	/**
//@	 * Assert if the expected object and the actual object are the same. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertSame(String test, Object expected, Object actual)
//@	throws AssertionFailedException {
//@		assertion.assertSame(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected object and the actual object aren't the same. If
//@	 * they aren't, nothing happens. Otherwise, it throws a
//@	 * AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotSame(String test, Object expected, Object actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotSame(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected object and the actual object are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(String test, Object expected, Object actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected object and the actual object aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(String test, Object expected, Object actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected boolean and the actual boolean are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the boolean that is correct.
//@	 * @param actual
//@	 *            the boolean that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(String test, boolean expected, boolean actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected boolean and the actual boolean aren't equal. If
//@	 * they aren't, nothing happens. Otherwise, it throws a
//@	 * AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the boolean that is correct.
//@	 * @param actual
//@	 *            the boolean that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(String test, boolean expected, boolean actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected char and the actual char are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the char that is correct.
//@	 * @param actual
//@	 *            the char that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(String test, char expected, char actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected char and the actual char aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the char that is correct.
//@	 * @param actual
//@	 *            the char that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(String test, char expected, char actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected int and the actual int are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the int that is correct.
//@	 * @param actual
//@	 *            the int that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(String test, int expected, int actual) 
//@	throws AssertionFailedException {
//@		assertion.assertEquals(test, expected, actual) ;
//@	}
//@
//@	/**
//@	 * Assert if the expected int and the actual int aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the int that is correct.
//@	 * @param actual
//@	 *            the int that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(String test, int expected, int actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected byte and the actual byte are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the byte that is correct.
//@	 * @param actual
//@	 *            the byte that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(String test, byte expected, byte actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected byte and the actual byte aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the byte that is correct.
//@	 * @param actual
//@	 *            the byte that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(String test, byte expected, byte actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected long and the actual long are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the long that is correct.
//@	 * @param actual
//@	 *            the long that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(String test, long expected, long actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected long and the actual long aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the long that is correct.
//@	 * @param actual
//@	 *            the long that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(String test, long expected, long actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected short and the actual short are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the short that is correct.
//@	 * @param actual
//@	 *            the short that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(String test, short expected, short actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(test, expected, actual);
//@	}
//@
	//#ifdef DCLDCV11
//@	/**
//@	 * Assert if the expected float and the actual float are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the float that is correct.
//@	 * @param actual
//@	 *            the float that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(String test, float expected, float actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected float and the actual float aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the float that is correct.
//@	 * @param actual
//@	 *            the float that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(String test, float expected, float actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected double and the actual double are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the double that is correct.
//@	 * @param actual
//@	 *            the double that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(String test, double expected, double actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected double and the actual double aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the double that is correct.
//@	 * @param actual
//@	 *            the double that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(String test, double expected, double actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(test, expected, actual);
//@	}
	//#endif
//@
//@	/**
//@	 * Assert if the expected short and the actual short aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * 
//@	 * @param test
//@	 *            a String used to identify the assert.
//@	 * @param expected
//@	 *            the short that is correct.
//@	 * @param actual
//@	 *            the short that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(String test, short expected, short actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(test, expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the object is null. If it is, nothing happens. Otherwise, it
//@	 * throws a AssertionFailedException. It has a default String to identify
//@	 * itself.
//@	 * 
//@	 * @param object
//@	 *            the object to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNull(Object object)
//@	throws AssertionFailedException {
//@		assertion.assertNull(object);
//@	}
//@
//@	/**
//@	 * Assert if the object isn't null. If it isn't, nothing happens. Otherwise,
//@	 * it throws a AssertionFailedException. It has a default String to identify
//@	 * itself.
//@	 * 
//@	 * @param object
//@	 *            the object to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotNull(Object object)
//@			throws AssertionFailedException {
//@		assertion.assertNotNull(object);
//@	}
//@
//@	/**
//@	 * Assert if the boolean expression is true. If it is, nothing happens.
//@	 * Otherwise, it throws a AssertionFailedException. It has a default String
//@	 * to identify itself.
//@	 * 
//@	 * @param expression
//@	 *            the boolean expression to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertTrue(boolean expression)
//@			throws AssertionFailedException {
//@		assertion.assertTrue(expression);
//@	}
//@
//@	/**
//@	 * Assert if the boolean expression is false. If it is, nothing happens.
//@	 * Otherwise, it throws a AssertionFailedException. It has a default String
//@	 * to identify itself.
//@	 * 
//@	 * @param expression
//@	 *            the boolean expression to be tested.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertFalse(boolean expression)
//@			throws AssertionFailedException {
//@		assertion.assertFalse(expression);
//@	}
//@
//@	/**
//@	 * Assert if the expected object and the actual object are the same. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
//@	 * has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertSame(Object expected, Object actual)
//@	throws AssertionFailedException {
//@		assertion.assertSame(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected object and the actual object aren't the same. If
//@	 * they aren't, nothing happens. Otherwise, it throws a
//@	 * AssertionFailedException. It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotSame(Object expected, Object actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotSame(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected object and the actual object are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
//@	 * has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(Object expected, Object actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected object and the actual object aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the object that is correct.
//@	 * @param actual
//@	 *            the object that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(Object expected, Object actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected boolean and the actual boolean are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
//@	 * has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the boolean that is correct.
//@	 * @param actual
//@	 *            the boolean that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(boolean expected, boolean actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected boolean and the actual boolean aren't equal. If
//@	 * they aren't, nothing happens. Otherwise, it throws a
//@	 * AssertionFailedException. It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the boolean that is correct.
//@	 * @param actual
//@	 *            the boolean that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(boolean expected, boolean actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected char and the actual char are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the char that is correct.
//@	 * @param actual
//@	 *            the char that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(char expected, char actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected char and the actual char aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the char that is correct.
//@	 * @param actual
//@	 *            the char that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(char expected, char actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected int and the actual int are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the int that is correct.
//@	 * @param actual
//@	 *            the int that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(int expected, int actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected int and the actual int aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the int that is correct.
//@	 * @param actual
//@	 *            the int that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(int expected, int actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected byte and the actual byte are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the byte that is correct.
//@	 * @param actual
//@	 *            the byte that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(byte expected, byte actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected byte and the actual byte aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the byte that is correct.
//@	 * @param actual
//@	 *            the byte that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(byte expected, byte actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected long and the actual long are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the long that is correct.
//@	 * @param actual
//@	 *            the long that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(long expected, long actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected long and the actual long aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the long that is correct.
//@	 * @param actual
//@	 *            the long that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(long expected, long actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected short and the actual short are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the short that is correct.
//@	 * @param actual
//@	 *            the short that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(short expected, short actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected short and the actual short aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the short that is correct.
//@	 * @param actual
//@	 *            the short that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(short expected, short actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(expected, actual);
//@	}
//@
	//#ifdef DCLDCV11
//@	/**
//@	 * Assert if the expected float and the actual float are equal. If they are,
//@	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
//@	 * a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the float that is correct.
//@	 * @param actual
//@	 *            the float that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(float expected, float actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected float and the actual float aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the float that is correct.
//@	 * @param actual
//@	 *            the float that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(float expected, float actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected double and the actual double are equal. If they
//@	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
//@	 * has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the double that is correct.
//@	 * @param actual
//@	 *            the double that should be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertEquals(double expected, double actual)
//@	throws AssertionFailedException {
//@		assertion.assertEquals(expected, actual);
//@	}
//@
//@	/**
//@	 * Assert if the expected double and the actual double aren't equal. If they
//@	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
//@	 * It has a default String to identify itself.
//@	 * 
//@	 * @param expected
//@	 *            the double that is correct.
//@	 * @param actual
//@	 *            the double that shouldn't be correct.
//@	 * @throws AssertionFailedException
//@	 *             if the assertion fail.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void assertNotEquals(double expected, double actual)
//@	throws AssertionFailedException {
//@		assertion.assertNotEquals(expected, actual);
//@	}
	//#endif
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
//@	public final void
	//#endif
//@		fail(String test) throws AssertionFailedException {
//@		assertion.fail(test);
//@	}
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void fail(String test, short expected, short actual)
//@	throws AssertionFailedException {
//@		assertion.fail(test, expected, actual);
//@	}
//@
	//#ifdef DCLDCV11
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void fail(String test, float expected, float actual)
//@	throws AssertionFailedException {
//@		assertion.fail(test, expected, actual);
//@	}
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void fail(String test, double expected, double actual)
//@	throws AssertionFailedException {
//@		assertion.fail(test, expected, actual);
//@	}
	//#endif
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void fail(String test, long expected, long actual)
//@	throws AssertionFailedException {
//@		assertion.fail(test, expected, actual);
//@	}
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void fail(String test, byte expected, byte actual)
//@	throws AssertionFailedException {
//@		assertion.fail(test, expected, actual);
//@	}
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void fail(String test, int expected, int actual)
//@	throws AssertionFailedException {
//@		assertion.fail(test, expected, actual);
//@	}
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void fail(String test, char expected, char actual)
//@	throws AssertionFailedException {
//@		assertion.fail(test, expected, actual);
//@	}
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void fail(String test, boolean expected, boolean actual)
//@	throws AssertionFailedException {
//@		assertion.fail(test, expected, actual);
//@	}
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition. It receives some identification parameters, used by the
//@	 * framework in the console fail report.
//@	 * 
//@	 * @param test
//@	 *            the identification of what failed.
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void fail(String test, Object expected, Object actual)
//@	throws AssertionFailedException {
//@		assertion.fail(test, expected, actual);
//@	}
//@
//@	/**
//@	 * This method is used to notify the framework that a assertion failed. It
//@	 * also may be used by the developers to produce a fail in some special
//@	 * condition.
//@	 * 
//@	 * @throws AssertionFailedException
//@	 *             as result of a failed assertion.
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void fail() throws AssertionFailedException {
//@		assertion.fail();
//@	}
//@
//@}
//#endif

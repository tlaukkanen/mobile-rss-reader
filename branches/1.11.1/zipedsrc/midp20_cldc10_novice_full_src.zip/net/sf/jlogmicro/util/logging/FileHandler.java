/*
 * FileHandler.java
 *
 * Copyright (C) 2007 Irving Bunton
 * http://code.google.com/p/jlogmicro/source
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * Alternately, at your option, you can redistribute the software and/or modify
 * it under the terms the GNU Lessor General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License or
 * GNU Lesser Public License
 * along with this program; if not, write to the Free Software Foundation, Inc.,
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
/*
 * IB 2010-07-10 1.1Alpha4 Add LGPL V2.1 and later as an option as a license choice in addition to GPL.
 * IB 2010-07-10 1.1Alpha4 Update source text to make distribution/redistribution license options clearer.
 * IB 2010-07-10 1.1Alpha4 Change to using open/close/remove vs openView/closeView/removeView as they are the same.
 * IB 2010-07-10 1.1Alpha4 Implement flush.
 */
// Expand to define CLDC define
//#define DCLDCV10
// Expand to define DJSR75 define
//#define DNOJSR75
// Expand to define logging define
//#define DLOGGING
//#ifdef DLOGGING
//#ifdef DJSR75
//@package net.sf.jlogmicro.util.logging;
//@
//@import java.util.Date;
//@import java.util.Vector;
//@import java.util.Hashtable;
//@import java.io.DataOutputStream;
//@import java.io.IOException;
//@import javax.microedition.io.file.FileConnection;
//@import javax.microedition.io.Connector;
//@
//@import net.sf.jlogmicro.util.logging.Handler;
//@import net.sf.jlogmicro.util.logging.LogRecord;
//@
//@public class FileHandler extends BufferedHandler {
//@
//@	private FileConnection fc = null;
//@
//@	public FileHandler() {
//@	}
//@
//@	public Object open(boolean append) {
//@		try {
//@			if (view == null) {
//@				fc = (FileConnection)Connector.open( name,
//@						Connector.READ | Connector.WRITE );
//@				if (!fc.exists()) {
//@					fc.create();
//@				}
//@				if (append) {
//@					view = new DataOutputStream(fc.openOutputStream(
//@								fc.fileSize()));
//@				} else {
//@					view = fc.openDataOutputStream();
//@				}
//@			}
//@			return view;
//@		} catch (Throwable e) {
//@			System.err.println("File open error " + name + "," +
//@					e.getMessage() + "," + e.getClass().getName());
//@			e.printStackTrace();
//@		}
//@		return view;
//@	}
//@
//@	public void remove() {
//@		try {
//@			if (view == null) {
//@				open(false);
//@			}
//@			((DataOutputStream)view).close();
//@			fc.delete();
//@			close();
//@		} catch (Throwable e) {
//@			System.err.println("File open error " + name + "," +
//@					e.getMessage() + "," + e.getClass().getName());
//@			e.printStackTrace();
//@		}
//@	}
//@
//@    public void close() {
//@		try {
//@			if (view != null) {
//@				((DataOutputStream)view).close();
//@			}
//@			if (fc != null) {
//@				fc.close();
//@			}
//@		} catch (IOException e) {
//@			e.printStackTrace();
//@		} finally {
//@			view = null;
//@			fc = null;
//@		}
//@	}
//@
//@    public void flush() {
//@		try {
//@			if (view != null) {
//@				((DataOutputStream)view).flush();
//@			}
//@		} catch (IOException e) {
//@			e.printStackTrace();
//@		} finally {
//@			view = null;
//@			fc = null;
//@		}
//@	}
//@
//@	public void publish(LogRecord record) {
//@		synchronized (this) {
//@			/* FIX
//@			int fsize = form.size();
//@			if ((maxEntries != 0) && (fsize >= maxEntries)) {
//@				form.delete(fsize - 1);
//@			}
//@			*/
//@			try {
//@				if (view == null) {
//@					open(true);
//@				}
//@				String fmtRec = formatter.format(record);
//@				((DataOutputStream)view).writeUTF(formatter.format(record) + "\n");
//@			} catch (OutOfMemoryError e) {
//@				record.setMessage("Out of memory.  Cannot log message.");
//@				try {
//@					((DataOutputStream)view).writeUTF(
//@						formatter.format(record) + "\n");
//@				} catch (Throwable e2) {
//@					System.err.println(
//@							"File write error from out of memory " +
//@							name + "," +
//@							e2.getMessage() + "," + e2.getClass().getName());
//@					e.printStackTrace();
//@				}
//@			} catch (Throwable e) {
//@				System.err.println("File write error " + name + "," +
//@						e.getMessage() + "," + e.getClass().getName());
//@				e.printStackTrace();
//@			}
//@		}
//@	}
//@
//@}
//#endif
//#endif

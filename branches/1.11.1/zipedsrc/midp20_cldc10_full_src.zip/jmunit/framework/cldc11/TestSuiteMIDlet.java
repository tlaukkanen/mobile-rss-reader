/*
 * TestSuiteMIDlet.java
 *
 * Copyright 2006 Brunno Silva
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Expand to define JMUNITPLUS define
//#define DNOJMTESTPLUS
//#ifdef DJMTESTPLUS
//@package jmunit.framework.cldc11;
//@
//@import java.util.Vector;
//@
//@/**
//@ * The TestSuiteMIDlet class is responsible for execute many TestCases. As it extends
//@ * Test, it can be used as a MIDlet in a simulator. To use it, it's necessary to
//@ * create a subclass with a super() declaration in the constructor. The method
//@ * add(TestCase testCase) must be used in the constructor of the subclass,
//@ * adding the TestCases objects that are necessary to be runned. When everthing
//@ * is coded, the TestSuiteMIDlet can be used in the simulator.
//@ * 
//@ * @author Brunno Silva
//@ * @since JMUnit 1.0
//@ */
//@public class TestSuiteMIDlet extends TestMIDlet
//#ifdef DJMTESTPLUS
//@implements TestSuiteInterface
//#endif
//@{
//@
//@	/**
//@	 * The default constructor. As such TestSuiteMIDlet can be added to MIDlet list as
//@	 * is and it will take list of classes to test from JMUnitTestClasses
//@	 * property.
//@	 * 
//@	 * @since JMUnit 1.0
//@	 */
//@	public TestSuiteMIDlet() {
//@		super();
//@		super.setTestMain(new TestSuite(this, true));
		//#ifdef DLOGGING
//@		if (finestLoggable) {logger.finest("Constructor super.getName()=" + super.getName());}
		//#endif
//@	}
//@
//@	/**
//@	 * The default constructor. As such TestSuiteMIDlet can be added to MIDlet list as
//@	 * is and it will take list of classes to test from JMUnitTestClasses
//@	 * property.
//@	 * 
//@	 * @since JMUnit 1.0
//@	 */
//@	public TestSuiteMIDlet(TestSuite testSuite) {
//@		super(testSuite);
		//#ifdef DLOGGING
//@		if (finestLoggable) {logger.finest("Constructor super.getName()=" + super.getName());}
		//#endif
//@	}
//@
//@	/**
//@	 * The purpose of this method is store Tests.
//@	 * 
//@	 * Note: JMUnit 1.0 allowed only TestCases to be added.
//@	 * 
//@	 * @param test
//@	 *            the Test to be added.
//@	 * 
//@	 * @since JMUnit 1.1
//@	 */
//@	public final void add(Test test) {
//@		((TestSuite)testMain).add(test);
//@	}
//@
//@	/**
//@	 * Counts the number of test cases that will be run by this test.
//@	 * 
//@	 * @since JMUnit 1.1
//@	 */
//@	public int countTestCases() {
//@		return ((TestSuite)testMain).countTestCases();
//@	}
//@
//@	/**
//@	 * Runs a test and collects its result in a TestResult instance.
//@	 * 
//@	 * @since JMunit 1.1
//@	 */
//@	public void run(TestResult result) {
//@		((TestSuite)testMain).run(result);
//@	}
//@
//@	/**
//@	 * Removes all tests from the TestSuite.
//@	 * 
//@	 * @since JMunit 1.1
//@	 */
//@	public void removeAll() {
//@		((TestSuite)testMain).removeAll();
//@	}
//@}
//#endif

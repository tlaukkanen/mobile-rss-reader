/*
 * HtmlLinkParserCompatibility4Test.java
 *
 * Copyright (C) 2009 Irving Bunton
 * http://code.google.com/p/mobile-rss-reader/
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

// Expand to define MIDP define
//#define DMIDP20
// Expand to define memory size define
//#define DREGULARMEM
// Expand to define test define
//#define DTEST
// Expand to define JMUnit test define
//#define DJMTEST
// Expand to define logging define
//#define DLOGGING

//#ifndef DSMALLMEM
//#ifdef DJMTEST
package com.substanceofcode.jmunit.businesslogic;

import java.util.Date;

import jmunit.framework.cldc10.TestCase;

import com.substanceofcode.rssreader.businessentities.RssItunesFeedInfo;
import com.substanceofcode.rssreader.businessentities.RssItunesFeed;
import com.substanceofcode.rssreader.businesslogic.RssFeedParser;
import com.substanceofcode.rssreader.businesslogic.CompatibilityRssFeedParser4;
import com.substanceofcode.rssreader.businessentities.CompatibilityRssItunesFeed4;
//#ifndef DSMALLMEM
import com.substanceofcode.rssreader.businesslogic.HTMLLinkParser;
import com.substanceofcode.rssreader.businesslogic.CompatibilityHTMLLinkParser4;
//#endif
//#ifdef DMIDP20
import net.eiroca.j2me.observable.Observer;
import net.eiroca.j2me.observable.Observable;
//#endif

import com.substanceofcode.jmunit.utilities.BaseTestCase;

final public class HtmlLinkParserCompatibility4Test extends BaseTestCase
//#ifdef DMIDP20
implements Observer
//#endif
{

	private boolean ready = false;

	public HtmlLinkParserCompatibility4Test() {
		super(1, "HtmlLinkParserCompatibility4Test");
	}

	public void test(int testNumber) throws Throwable {
		switch (testNumber) {
			case 0:
				testHtmlParse1();
				break;
			default:
				fail("Bad number for switch testNumber=" + testNumber);
				break;
		}
	}

	//#ifdef DMIDP20
	public void changed(Observable observable) {
		ready = true;
	}
	//#endif

	public boolean isReady() {
		return ready;
	}

	/* Test parse HTML. */
	public void testHtmlParse1() throws Throwable {
		String mname = "testHtmlParse1";
		HTMLLinkParser htmlParser = new HTMLLinkParser(
				"jar:///links.html", "", "");
		CompatibilityHTMLLinkParser4 cmpHtmlParser =
			new CompatibilityHTMLLinkParser4("jar:///links.html", "", "");

		compatibilityHtmlLinkParserTestSub(mname, htmlParser, cmpHtmlParser);
	}

    public void compatibilityHtmlLinkParserTestSub(final String mname,
			final HTMLLinkParser htmlParser,
			final CompatibilityHTMLLinkParser4 compatibilityHtmlParser)
	throws Throwable {
		try {
			//#ifdef DLOGGING
			logger.info("Started " + mname);
			if (finestLoggable) {logger.finest(mname + " compatibilityHtmlLinkParserTestSub=" + htmlParser);}
			//#endif
			ready = false;
			//#ifdef DMIDP20
			htmlParser.getObserverManager().addObserver(this);
			//#endif
			htmlParser.startParsing();
			//#ifdef DMIDP20
			while (!isReady()) {
				synchronized(this) {
					wait(1000L);
				}
			}
			//#else
//@			htmlParser.join();
			//#endif
			//#ifdef DLOGGING
			if (finestLoggable) {logger.finest(mname + " htmlParser.isSuccessfull()=" + htmlParser.isSuccessfull());}
			//#endif
			RssItunesFeedInfo[] rssfeeds = htmlParser.getFeeds();
			compatibilityHtmlParser.startParsing();
			compatibilityHtmlParser.join();
			if (finestLoggable) {logger.finest(mname + " compatibilityHtmlParser.isSuccessfull()=" + compatibilityHtmlParser.isSuccessfull());}
			CompatibilityRssItunesFeed4[] cmpRssFeeds =
				(CompatibilityRssItunesFeed4[])compatibilityHtmlParser.getFeeds();
			for (int i = 0; (i < rssfeeds.length) && (i < cmpRssFeeds.length);
					i++) {
				RssItunesFeedInfo feed = rssfeeds[i];
				//#ifdef DLOGGING
				if (finestLoggable) {logger.finest(mname + " i,feed 1=" + i + "," + feed.toString());}
				//#endif
				CompatibilityRssItunesFeed4 cmpfeed = cmpRssFeeds[i];
				//#ifdef DLOGGING
				if (finestLoggable) {logger.finest(mname + " i,cmpfeed 1=" + i + "," + cmpfeed.toString());}
				//#endif
				String assertInfo = new String("i,name,url=" + i + "," + feed.getName() + "," +  feed.getUrl());
				assertTrue("Original feed must equal expected feed " + assertInfo, cmpfeed.equals(feed));
				if (feed.getUrl().indexOf("http://") >= 0) {
					//#ifdef DLOGGING
					if (finestLoggable) {logger.finest(mname + " skipping http URL i,feed.getUrl() 2=" + i + "," + feed.getUrl());}
					//#endif
					continue;
				}
				RssFeedParser fparser = new RssFeedParser((RssItunesFeed)feed);
				//#ifdef DMIDP20
				fparser.makeObserable(null, true, 10);
				ready = false;
				fparser.getObserverManager().addObserver(this);
				fparser.getParsingThread().start();
				while (!isReady()) {
					synchronized(this) {
						wait(1000L);
					}
				}
				//#else
//@				fparser.parseRssFeed( false, 10);
				//#endif
				RssItunesFeedInfo nfeed = fparser.getRssFeed();
				//#ifdef DLOGGING
				if (finestLoggable) {logger.finest(mname + " i,feed 3=" + i + "," + feed.toString());}
				//#endif
				CompatibilityRssFeedParser4 cmpFparser = new CompatibilityRssFeedParser4(cmpfeed);
				//#ifdef DMIDP20
				cmpFparser.makeObserable(null, true, 10);
				ready = false;
				cmpFparser.getObserverManager().addObserver(this);
				cmpFparser.getParsingThread().start();
				while (!isReady()) {
					synchronized(this) {
						wait(1000L);
					}
				}
				//#else
//@				cmpFparser.parseRssFeed( false, 10);
				//#endif
				CompatibilityRssItunesFeed4 ncmpfeed = (CompatibilityRssItunesFeed4)cmpFparser.getRssFeed();
				//#ifdef DLOGGING
				if (finestLoggable) {logger.finest(mname + " i,ncmpfeed 3=" + i + "," + ncmpfeed.toString());}
				//#endif
				assertTrue("Feed must equal expected feed " + assertInfo, ncmpfeed.equals(nfeed));

			}
			//#ifdef DLOGGING
			if (finestLoggable) {logger.finest(mname + " finished.");}
			//#endif
		} catch (Throwable e) {
			//#ifdef DLOGGING
			logger.severe(mname + " failure ",e);
			//#endif
			e.printStackTrace();
			throw e;
		}
	}

}
//#endif
//#endif

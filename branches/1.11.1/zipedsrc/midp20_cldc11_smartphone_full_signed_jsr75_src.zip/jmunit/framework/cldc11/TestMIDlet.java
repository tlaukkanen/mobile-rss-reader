/*
 * TestMIDlet.java
 *  
 * Copyright 2006 Brunno Silva
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Expand to define logging define
//#define DLOGGING
// Expand to define JMUNITPLUS define
//#define DNOJMTESTPLUS
//#ifdef DJMTESTPLUS
//@package jmunit.framework.cldc11;
//@
//@import javax.microedition.midlet.MIDletStateChangeException;
//@import javax.microedition.midlet.MIDlet;
//@
//#ifdef DLOGGING
//@import net.sf.jlogmicro.util.logging.Logger;
//@import net.sf.jlogmicro.util.logging.LogManager;
//@import net.sf.jlogmicro.util.logging.Level;
//#endif
//@
//@/**
//@ * The TestMIDlet is a abstract class that has the main implementation to create a
//@ * executing test class or a utility class to execute others. The MIDlet methods
//@ * as startApp are localized here.
//@ * 
//@ * @author Brunno Silva
//@ * @since JMUnit 1.0
//@ */
//@public abstract class TestMIDlet
//@extends AssertionMIDlet
//@implements TestInterface
//@{
//@	/**
//@	 * The test used to implement the TestInterface.
//@	 */
//@	protected TestInterface testMain;
//@
	//#ifdef DLOGGING
//@    protected boolean fineLoggable;
//@    protected boolean finestLoggable;
//@    protected Logger logger;
	//#endif
//@
//@	/**
//@	 * The constructor.
//@	 * 
//@	 * @since JMUnit 1.0
//@	 */
//@	public TestMIDlet() {
//@		super();
		//#ifdef DLOGGING
//@		initLogging();
		//#endif
//@		testMain = null;
//@		Test.setTestMidlet(this);
//@	}
//@
//@	/**
//@	 * The constructor.
//@	 * 
//@	 * @since JMUnit 1.0
//@	 */
//@	public TestMIDlet(Test test) {
//@		super();
		//#ifdef DLOGGING
//@		initLogging();
		//#endif
//@		testMain = test;
//@		assertion = test;
//@		Test.setTestMidlet(this);
//@	}
//@
	//#ifdef DLOGGING
//@	private void initLogging() {
//@		LogManager logManager = LogManager.getLogManager();
//@		logManager.readConfiguration(this);
//@		logger = Logger.getLogger("TestMIDlet");
//@		logger.info("TestMIDlet started.");
//@		fineLoggable = logger.isLoggable(Level.FINE);
//@		logger.fine("obj,fineLoggable=" + this + "," + fineLoggable);
//@		finestLoggable = logger.isLoggable(Level.FINEST);
//@		logger.fine("obj,finestLoggable=" + this + "," + finestLoggable);
//@	}
	//#endif
//@
//@	/**
//@	 * The startApp puts the screen in the simulator interface.
//@	 * 
//@	 * @since JMUnit 1.0
//@	 */
//@	/* UNDO */
	//#ifdef DJMTEST
//@	public
	//#else
//@	public final
	//#endif
//@		void startApp() throws MIDletStateChangeException {
//@		startTestApp();
//@	}
//@
//@	/**
//@	 * The startApp puts the screen in the simulator interface.
//@	 * 
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void startTestApp() {
//@		testMain.startTestApp();
//@	}
//@
//@	/**
//@	 * The doStart method is a template method that is called when an app is
//@	 * started. A class should override it if it needs to do something special
//@	 * when a MIDlet starts.
//@	 * 
//@	 * @since JMUnit 1.1
//@	 */
//@	public void doStart() {
//@	}
//@
//@	/**
//@	 * It's an empty method.
//@	 * 
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void pauseApp() {
//@
//@	}
//@
//@	/**
//@	 * It's an empty method.
//@	 * 
//@	 * @param unconditional
//@	 *            an irrelevant boolean.
//@	 * @since JMUnit 1.0
//@	 */
	//#ifdef DJMTEST
//@	public
	//#else
//@	public final
	//#endif
//@		void destroyApp(boolean unconditional)
//@	  throws MIDletStateChangeException {
//@	}
//@
//@	/**
//@	 * This convenience method runs all the tests and creates a TestResult if
//@	 * necessary.
//@	 * 
//@	 * @since JMUnit 1.0
//@	 */
//@	public final void test() {
//@		testMain.test();
//@	}
//@
//@	/**
//@	 * This method sets the name of the test.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	public final void setName(String name) {
//@		testMain.setName(name);
//@	}
//@
//@	/**
//@	 * Counts the number of test cases that will be run by this test.
//@	 * 
//@	 * @since JMUnit 1.1
//@	 */
//@	public String getName() {
//@		return testMain.getName();
//@	}
//@
//@	/**
//@	 * Counts the number of test cases that will be run by this test.
//@	 * 
//@	 * @since JMUnit 1.1
//@	 */
//@	public abstract int countTestCases();
//@
//@	/**
//@	 * Runs a test and collects its result in a TestResult instance.
//@	 * 
//@	 * @since JMunit 1.1
//@	 */
//@	public abstract void run(TestResult result);
//@
//@    public void setTestMain(TestInterface testMain) {
//@        this.testMain = testMain;
//@        this.assertion = assertion;
//@    }
//@
//@    public TestInterface getTestMain() {
//@        return (testMain);
//@    }
//@
//@}
//#endif

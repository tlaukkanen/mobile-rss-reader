/*
 * TestRunnerInterface.java
 *  
 * Copyright 2008 C.A. Meijer
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/*
 * This was first modified on 2011/01/08
 */
// Expand to define JMUNITPLUS define
//#define DNOJMTESTPLUS
//#ifdef DJMTESTPLUS
//@package jmunit.framework.cldc11;
//@
//@import java.util.Date;
//@import java.util.Vector;
//@
//@/**
//@ * The TestRunnerInterface class runs a test immediately on launching of a MIDlet. The
//@ * MIDlet shuts down shortly after the tests finish. This class should be used
//@ * 
//@ * @author C.A. Meijer
//@ * @since JMUnit 1.1.
//@ */
//@public interface TestRunnerInterface {
//@
//@	/**
//@	 * We override the doStart method to run the tests immediately.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	void doStart();
//@
//@	/**
//@	 * Counts the number of tests.
//@	 * 
//@	 * @return The number of test cases.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	int countTestCases();
//@
//@	/**
//@	 * Runs and reports the tests.
//@	 * 
//@	 * @param results
//@	 *            The TestResult where the results are gathered.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	void run(TestResult results);
//@
//@}
//#endif

/*
 * PageCanvas.java
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

// Expand to define MIDP define
//#define DMIDP20

//#ifdef DMIDP20

package cz.cacek.ebook;

import java.util.Vector;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Gauge;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;

import com.substanceofcode.rssreader.presentation.RssReaderMIDlet;

/**
 * Main display. On this canvas is displayed current part of book.
 * @author Tom� Darmovzal [tomas.darmovzal (at) seznam.cz]
 * @author Josef Cacek [josef.cacek (at) atlas.cz]
 * @author Jiri Bartos
 * @author $Author: kwart $
 * @version $Revision: 1.18 $
 * @created $Date: 2006/12/26 09:08:49 $
 */
public class PageCanvas extends Canvas implements CommandListener {

	private List list;

	private RssReaderMIDlet midlet;
	protected View view;
	private String message = null;
	private Font messageFont;
	private Command cmdInfo;
	private Command cmdPosition;
	private Command cmdBack;
	private Command cmdColor;

	private Command cmdOK;
	private Command cmdCancel;
	
	private Gauge gauge;
	private Form form;
	
	protected final ScrollThread scrollThread  = new ScrollThread();

	private Vector listVector;
	private static int scrollDelay = Common.AUTOSCROLL_PAUSE;

	private byte screenIdx;
	private Display display;

	/**
	 * Thread which provides autoscroll functionality.
	 * @author Josef Cacek
	 */
	class ScrollThread extends Thread {
		boolean run = false;

		public void run() {			
			try {				
				while (true) {
					if (canRun()) {
						if (!view.fwdLine()) {
							setRun(false);	
						}						
						messageOff();
					}
					Thread.sleep(getScrollDelay());
				}
			} catch (Exception e) {}
		}

		public synchronized void setRun(final boolean aRun) {
			run = aRun;
			if (!run) {
				messageOff();
			}
		}

		public synchronized boolean canRun() {
			return run;
		}
	}

	/**
	 * Constructor
	 * @param aMidlet
	 * @throws Exception
	 */
	public PageCanvas(RssReaderMIDlet aMidlet) throws Exception {
		midlet = aMidlet;
		display = Display.getDisplay(midlet);
		view = new View(getWidth(), getHeight());
		messageFont = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD,
			Font.SIZE_SMALL);
		cmdInfo = new Command(ResourceProviderME.get("cmd.info"), Command.SCREEN, 3);
		cmdPosition = new Command(ResourceProviderME.get("cmd.position"), Command.SCREEN, 2);
		cmdBack = new Command(ResourceProviderME.get("cmd.exit"), Command.SCREEN, 5);
		cmdOK = new Command(ResourceProviderME.get("btn.ok"), Command.OK, 1);
		cmdCancel = new Command(ResourceProviderME.get("btn.cancel"), Command.CANCEL, 1);
		addCommand(cmdPosition);
		addCommand(cmdInfo);
		addCommand(cmdBack);
		setCommandListener(this);
		scrollThread.start();
	}


	/**
	 * Constructs reusable gauge screen.
	 * @param aHead resource key for screen header
	 * @param aGauge resource key for gauge description
	 * @param aValue initial value on gauge
	 */
	private void createGaugeForm(final String aHead, final String aGauge, final int aValue, final byte aScreenIdx) {
		form = new Form(ResourceProviderME.get(aHead));
		if (aValue<0 || aValue>100) {
			throw new RuntimeException("Wrong parameters for Gauge constructor");
		}
		gauge = new Gauge(ResourceProviderME.get(aGauge), true, 100, 0);
		form.append(gauge);
        gauge.setValue(aValue);
		form.addCommand(cmdOK);
		form.addCommand(cmdCancel);
		form.setCommandListener(this);
		display.setCurrent(form);
		screenIdx = aScreenIdx;
	}

	private void releaseForm() {
		form = null;
		gauge = null;
		setPageScreen();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.microedition.lcdui.Displayable#paint(javax.microedition.lcdui.Graphics)
	 */
	public void paint(Graphics g) {
		Common.debug("EBookCanvas.paint(Graphics g)");
		view.draw(g, 0, 0);
		if (message != null) {
			int mx = 2;
			int my = 2;
			g.setFont(messageFont);
			int w = messageFont.stringWidth(message);
			int h = messageFont.getHeight();
			g.setColor(0xFFFFFF);
			g.fillRect(mx, my, w + 3, h + 3);
			g.setColor(0x000000);
			g.drawString(message, mx + 2, my + 2, Graphics.LEFT | Graphics.TOP);
			g.drawRect(mx, my, w + 3, h + 3);
		}
	}

	/* (non-Javadoc)
	 * @see javax.microedition.lcdui.Displayable#keyPressed(int)
	 */
	public void keyPressed(int aKey) {
		Common.debug("Key pressed " + aKey);
		key(aKey);
	}

	/* (non-Javadoc)
	 * @see javax.microedition.lcdui.Displayable#keyRepeated(int)
	 */
	public void keyRepeated(int aKey) {
		Common.debug("Key repeated " + aKey);
		key(aKey);
	}

	/**
	 * Key actions handler
	 * @param aKey
	 */
	protected synchronized void key(final int aKey) {
		final int action = getGameAction(aKey);
		Common.debug("Key: " + aKey + ", Action: " + action);
		if (!scrollThread.canRun()) {
			keyNormal(aKey, action);
		} else {
			keyAutoRun(aKey, action);					
		}
		Common.debug("Key action finished.");
	}


	/**
	 * Key actions handler
	 * @param aKey
	 */
	protected void keyNormal(final int aKey, final int action) {
		switch (action) {
			case UP:
				prevPage();
				break;
			case DOWN:
				nextPage();
				break;
			case RIGHT:
				nextLine();
				break;
			case LEFT:
				prevLine();
				break;
			default:
				switch (aKey) {
					case KEY_NUM1:
					case KEY_NUM2:
					case KEY_NUM3:
					case -13:
						prevPage();
						break;
					case KEY_NUM4:
						prevLine();
						break;
					case KEY_NUM7:
					case KEY_NUM8:
					case KEY_NUM9:
					case KEY_NUM0:
					case -14:
						nextPage();
						break;
					case KEY_NUM6:
						nextLine();
						break;
					case KEY_NUM5:
						scrollThread.setRun(true);
						break;
				}
		}
	}

	/**
	 * Key handlers for Autorun book reading.
	 * @param aKey
	 */
	protected void keyAutoRun(final int aKey, final int action) {
		if (action == UP || action == LEFT || aKey == KEY_NUM4) {
			addScrollDelay(Common.AUTOSCROLL_STEP);
		} else if (action == DOWN || action == RIGHT || aKey == KEY_NUM6) {
			addScrollDelay(- Common.AUTOSCROLL_STEP);
		} 
		if (aKey == KEY_NUM5) {
			messageOn(ResourceProviderME.get("i.stop"));
			scrollThread.setRun(false);
		} else {
			messageOn(ResourceProviderME.get("i.delay")+getScrollDelay());
		}
	}
	/* (non-Javadoc)
	 * @see javax.microedition.lcdui.Displayable#pointerPressed(int, int)
	 */
	public void pointerPressed(int aX, int aY) {
		Common.debug("Pointer pressed (" + aX + "," + aY + ")");
		int seg = (aY * 4) / getHeight();
		if (scrollThread != null) {
			return;
		}
		synchronized (this) {
			switch (seg) {
				case 0:
					prevPage();
					break;
				case 1:
					prevLine();
					break;
				case 2:
					nextLine();
					break;
				case 3:
					nextPage();
					break;
			}
		}
	}

	/* (non-Javadoc)
	 * @see javax.microedition.lcdui.CommandListener#commandAction(javax.microedition.lcdui.Command, javax.microedition.lcdui.Displayable)
	 */
	public void commandAction(Command aCmd, Displayable aDisp) {
		Common.debug("Command action " + aCmd);
		switch (screenIdx) {
			case Common.SCREEN_PAGE :
				commandActNormal(aCmd);
				break;
			case Common.SCREEN_POSITION :
				commandActPosition(aCmd);
				break;
			default :
				break;
		}

	}

	private void commandActPosition(final Command aCmd) {
		Common.debug("commandAction() for book list started");
		if (form != null && aCmd == cmdOK) {
			view.setPercPosition(gauge.getValue());
			view.fillPage();
			releaseForm();
		}
	}

	/**
	 * 
	 */
	private void setPage(final Page page) {
		view.setPage(page);
		setPageScreen();
	}

	private void setPageScreen() {
		display.setCurrent(this);
		screenIdx = Common.SCREEN_PAGE;
	}
	
	private void commandActNormal(final Command aCmd) {
		if (aCmd == cmdBack) {
			midlet.showBookmarkList();
		} else if (aCmd == cmdPosition) {
			createGaugeForm("pos.head", "pos.actual", view.getPercPosition(), Common.SCREEN_POSITION);
		} else if (aCmd == cmdInfo) {
			midlet.showItemForm();
		}
	}

	/**
	 * Scrolls one line ahead in current book
	 */
	protected void nextLine() {
		try {
			pauseOn();
			view.fwdLine();
			messageOff();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Scrolls one page ahead in current book
	 */
	protected void nextPage() {
		try {
			pauseOn();
			view.fwdPage();
			messageOff();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Scrolls one line back in current book
	 */
	protected void prevLine() {
		try {
			pauseOn();
			view.bckLine();
			messageOff();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Scrolls one page back in current book
	 */
	protected void prevPage() {
		try {
			pauseOn();
			view.bckPage();
			messageOff();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Displays "Wait" message
	 */
	protected void pauseOn() {
		messageOn(ResourceProviderME.get("i.wait"));
	}

	/**
	 * Displays system message (e.g. Wait) display
	 */
	protected synchronized void messageOn(final String aMsg) {
		message = aMsg;
		repaint();
		serviceRepaints();
	}

	/**
	 * Disable system message (e.g. Wait) display
	 */
	protected synchronized void messageOff() {
		message = null;
		repaint();
//		serviceRepaints();
	}

	/* (non-Javadoc)
	 * @see javax.microedition.lcdui.Displayable#hideNotify()
	 */
	protected void hideNotify() {
		Common.debug("EBookCanvas.hideNotify()");
		scrollThread.setRun(false);
	}

	/**
	 * Sets pause between scrolling.
	 * @param aDelay
	 */
	public static synchronized void setScrollDelay(int aDelay) {
		if (aDelay < Common.AUTOSCROLL_STEP) {
			aDelay = Common.AUTOSCROLL_STEP;
		}
		scrollDelay = aDelay;
	}

	public static synchronized void addScrollDelay(int aDelay) {
		setScrollDelay(getScrollDelay() + aDelay);
	}    

	/**
	 * Returns position of view.
	 * @see View#getPosition()
	 * @return position of view
	 */
	public int getViewPosition() {
		return view.getPosition();
	}

	/**
	 * @return Returns the scrollDelay.
	 */
	public static synchronized int getScrollDelay() {
		return scrollDelay;
	}

}
//#endif

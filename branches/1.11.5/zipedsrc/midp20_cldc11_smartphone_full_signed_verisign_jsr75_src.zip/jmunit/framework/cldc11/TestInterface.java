/*
 * Test.java
 *  
 * Copyright 2006 Brunno Silva
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Expand to define JMUNITPLUS define
//#define DNOJMTESTPLUS
//#ifdef DJMTESTPLUS
//@package jmunit.framework.cldc11;
//@
//@/**
//@ * The Test is a abstract class that has the main implementation to create a
//@ * executing test class or a utility class to execute others. The MIDlet methods
//@ * as startApp are localized here.
//@ * 
//@ * @author Brunno Silva
//@ * @since JMUnit 1.0
//@ */
//@public interface TestInterface {
//@	/**
//@	 * The startApp puts the screen in the simulator interface.
//@	 * 
//@	 * @since JMUnit 1.0
//@	 */
//@	void startTestApp();
//@
//@	/**
//@	 * The doStart method is a template method that is called when an app is
//@	 * started. A class should override it if it needs to do something special
//@	 * when a MIDlet starts.
//@	 * 
//@	 * @since JMUnit 1.1
//@	 */
//@	public void doStart();
//@
//@	/**
//@	 * This convenience method runs all the tests and creates a TestResult if
//@	 * necessary.
//@	 * 
//@	 * @since JMUnit 1.0
//@	 */
//@	void test();
//@
//@	/**
//@	 * This method sets the name of the test.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	void setName(String name);
//@
//@	/**
//@	 * This method gets the names of the test.
//@	 * 
//@	 * @return The test name.
//@	 * 
//@	 * @since JMUnit 1.1.
//@	 */
//@	String getName();
//@
//@	/**
//@	 * Counts the number of test cases that will be run by this test.
//@	 * 
//@	 * @since JMUnit 1.1
//@	 */
//@	public int countTestCases();
//@
//@	/**
//@	 * Runs a test and collects its result in a TestResult instance.
//@	 * 
//@	 * @since JMunit 1.1
//@	 */
//@	public void run(TestResult result);
//@}
//#endif

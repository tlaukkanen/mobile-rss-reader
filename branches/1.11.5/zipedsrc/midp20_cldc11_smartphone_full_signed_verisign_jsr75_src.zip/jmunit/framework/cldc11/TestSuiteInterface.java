/*
 * TestSuite.java
 *
 * Copyright 2006 Brunno Silva
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/*
 * This was changed on 2011/01/09.
 */

// Expand to define JMUNITPLUS define
//#define DNOJMTESTPLUS
//#ifdef DJMTESTPLUS
//@package jmunit.framework.cldc11;
//@
//@import java.util.Vector;
//@
//@/**
//@ * The TestSuite class is responsible for execute many TestCases. As it extends
//@ * Test, it can be used as a MIDlet in a simulator. To use it, it's necessary to
//@ * create a subclass with a super() declaration in the constructor. The method
//@ * add(TestCase testCase) must be used in the constructor of the subclass,
//@ * adding the TestCases objects that are necessary to be runned. When everthing
//@ * is coded, the TestSuite can be used in the simulator.
//@ * 
//@ * @author Brunno Silva
//@ * @since JMUnit 1.0
//@ */
//@public interface TestSuiteInterface
//@{
//@
//@	/**
//@	 * The purpose of this method is store Tests.
//@	 * 
//@	 * Note: JMUnit 1.0 allowed only TestCases to be added.
//@	 * 
//@	 * @param test
//@	 *            the Test to be added.
//@	 * 
//@	 * @since JMUnit 1.1
//@	 */
//@	void add(Test test);
//@
//@	/**
//@	 * Counts the number of test cases that will be run by this test.
//@	 * 
//@	 * @since JMUnit 1.1
//@	 */
//@	public int countTestCases();
//@
//@	/**
//@	 * Runs a test and collects its result in a TestResult instance.
//@	 * 
//@	 * @since JMunit 1.1
//@	 */
//@	public void run(TestResult result);
//@
//@	/**
//@	 * Removes all tests from the TestSuite.
//@	 * 
//@	 * @since JMunit 1.1
//@	 */
//@	public void removeAll();
//@
//@}
//#endif

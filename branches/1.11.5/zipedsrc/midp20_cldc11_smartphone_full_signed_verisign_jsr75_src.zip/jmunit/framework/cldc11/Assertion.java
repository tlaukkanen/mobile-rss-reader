/*
 * Assertion.java
 *  
 * Copyright 2006 Brunno Silva
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Expand to define MIDP define
//#define DCLDCV11
// Expand to define JMUNITPLUS define
//#define DNOJMTESTPLUS

package jmunit.framework.cldc11;

import javax.microedition.midlet.MIDlet;

/**
 * The root class for the test classes tree. It has all the basic assertions and
 * main methods used by the developers to create the tests.
 * 
 * @author Brunno Silva
 * @since JMUnit 1.0
 */
public abstract class Assertion
//#ifdef DJMTESTPLUS
//@implements AssertionInterface
//#else
extends MIDlet
//#endif
{

	private static final String ASSERT_EQUALS_FAILED = "Assert equals failed.";

	private static final String ASSERT_NOT_EQUALS_FAILED = "Assert not equals failed.";

	/**
	 * Assert if the object is null. If it is, nothing happens. Otherwise, it
	 * throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param object
	 *            the object to be tested.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNull(String test, Object object)
			throws AssertionFailedException {
		if (object != null) {
			fail(test);
		}
	}

	/**
	 * Assert if the object isn't null. If it isn't, nothing happens. Otherwise,
	 * it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param object
	 *            the object to be tested.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotNull(String test, Object object)
			throws AssertionFailedException {
		if (object == null) {
			fail(test);
		}
	}

	/**
	 * Assert if the boolean expression is true. If it is, nothing happens.
	 * Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expression
	 *            the boolean expression to be tested.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertTrue(String test, boolean expression)
			throws AssertionFailedException {
		if (!expression) {
			fail(test);
		}
	}

	/**
	 * Assert if the boolean expression is false. If it is, nothing happens.
	 * Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expression
	 *            the boolean expression to be tested.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertFalse(String test, boolean expression)
			throws AssertionFailedException {
		if (expression) {
			fail(test);
		}
	}

	/**
	 * Assert if the expected object and the actual object are the same. If they
	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the object that is correct.
	 * @param actual
	 *            the object that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertSame(String test, Object expected,
			Object actual) throws AssertionFailedException {
		if (expected != actual) {
			fail(test);
		}
	}

	/**
	 * Assert if the expected object and the actual object aren't the same. If
	 * they aren't, nothing happens. Otherwise, it throws a
	 * AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the object that is correct.
	 * @param actual
	 *            the object that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotSame(String test, Object expected,
			Object actual) throws AssertionFailedException {
		if (expected == actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected object and the actual object are equal. If they
	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the object that is correct.
	 * @param actual
	 *            the object that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(String test, Object expected,
			Object actual) throws AssertionFailedException {
		if (!expected.equals(actual)) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected object and the actual object aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the object that is correct.
	 * @param actual
	 *            the object that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(String test, Object expected,
			Object actual) throws AssertionFailedException {
		if (expected.equals(actual)) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected boolean and the actual boolean are equal. If they
	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the boolean that is correct.
	 * @param actual
	 *            the boolean that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(String test, boolean expected,
			boolean actual) throws AssertionFailedException {
		if (expected != actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected boolean and the actual boolean aren't equal. If
	 * they aren't, nothing happens. Otherwise, it throws a
	 * AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the boolean that is correct.
	 * @param actual
	 *            the boolean that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(String test, boolean expected,
			boolean actual) throws AssertionFailedException {
		if (expected == actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected char and the actual char are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the char that is correct.
	 * @param actual
	 *            the char that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(String test, char expected,
			char actual) throws AssertionFailedException {
		if (expected != actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected char and the actual char aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the char that is correct.
	 * @param actual
	 *            the char that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(String test, char expected,
			char actual) throws AssertionFailedException {
		if (expected == actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected int and the actual int are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the int that is correct.
	 * @param actual
	 *            the int that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(String test, int expected, int actual)
			throws AssertionFailedException {
		if (expected != actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected int and the actual int aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the int that is correct.
	 * @param actual
	 *            the int that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(String test, int expected,
			int actual) throws AssertionFailedException {
		if (expected == actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected byte and the actual byte are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the byte that is correct.
	 * @param actual
	 *            the byte that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(String test, byte expected,
			byte actual) throws AssertionFailedException {
		if (expected != actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected byte and the actual byte aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the byte that is correct.
	 * @param actual
	 *            the byte that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(String test, byte expected,
			byte actual) throws AssertionFailedException {
		if (expected == actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected long and the actual long are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the long that is correct.
	 * @param actual
	 *            the long that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(String test, long expected,
			long actual) throws AssertionFailedException {
		if (expected != actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected long and the actual long aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the long that is correct.
	 * @param actual
	 *            the long that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(String test, long expected,
			long actual) throws AssertionFailedException {
		if (expected == actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected short and the actual short are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the short that is correct.
	 * @param actual
	 *            the short that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(String test, short expected,
			short actual) throws AssertionFailedException {
		if (expected != actual) {
			fail(test, expected, actual);
		}
	}

	//#ifdef DCLDCV11
	/**
	 * Assert if the expected float and the actual float are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the float that is correct.
	 * @param actual
	 *            the float that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(String test, float expected,
			float actual) throws AssertionFailedException {
		if (expected != actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected float and the actual float aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the float that is correct.
	 * @param actual
	 *            the float that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(String test, float expected,
			float actual) throws AssertionFailedException {
		if (expected == actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected double and the actual double are equal. If they
	 * are, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the double that is correct.
	 * @param actual
	 *            the double that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(String test, double expected,
			double actual) throws AssertionFailedException {
		if (expected != actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the expected double and the actual double aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the double that is correct.
	 * @param actual
	 *            the double that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(String test, double expected,
			double actual) throws AssertionFailedException {
		if (expected == actual) {
			fail(test, expected, actual);
		}
	}
	//#endif

	/**
	 * Assert if the expected short and the actual short aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * 
	 * @param test
	 *            a String used to identify the assert.
	 * @param expected
	 *            the short that is correct.
	 * @param actual
	 *            the short that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(String test, short expected,
			short actual) throws AssertionFailedException {
		if (expected == actual) {
			fail(test, expected, actual);
		}
	}

	/**
	 * Assert if the object is null. If it is, nothing happens. Otherwise, it
	 * throws a AssertionFailedException. It has a default String to identify
	 * itself.
	 * 
	 * @param object
	 *            the object to be tested.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNull(Object object)
			throws AssertionFailedException {
		assertNull("Assert null failed.", object);
	}

	/**
	 * Assert if the object isn't null. If it isn't, nothing happens. Otherwise,
	 * it throws a AssertionFailedException. It has a default String to identify
	 * itself.
	 * 
	 * @param object
	 *            the object to be tested.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotNull(Object object)
			throws AssertionFailedException {
		assertNotNull("Assert not null failed.", object);
	}

	/**
	 * Assert if the boolean expression is true. If it is, nothing happens.
	 * Otherwise, it throws a AssertionFailedException. It has a default String
	 * to identify itself.
	 * 
	 * @param expression
	 *            the boolean expression to be tested.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertTrue(boolean expression)
			throws AssertionFailedException {
		assertTrue("Assert true failed.", expression);
	}

	/**
	 * Assert if the boolean expression is false. If it is, nothing happens.
	 * Otherwise, it throws a AssertionFailedException. It has a default String
	 * to identify itself.
	 * 
	 * @param expression
	 *            the boolean expression to be tested.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertFalse(boolean expression)
			throws AssertionFailedException {
		assertFalse("Assert false failed.", expression);
	}

	/**
	 * Assert if the expected object and the actual object are the same. If they
	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
	 * has a default String to identify itself.
	 * 
	 * @param expected
	 *            the object that is correct.
	 * @param actual
	 *            the object that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertSame(Object expected, Object actual)
			throws AssertionFailedException {
		assertSame("Assert same failed.", expected, actual);
	}

	/**
	 * Assert if the expected object and the actual object aren't the same. If
	 * they aren't, nothing happens. Otherwise, it throws a
	 * AssertionFailedException. It has a default String to identify itself.
	 * 
	 * @param expected
	 *            the object that is correct.
	 * @param actual
	 *            the object that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotSame(Object expected, Object actual)
			throws AssertionFailedException {
		assertNotSame("Assert not same failed.", expected, actual);
	}

	/**
	 * Assert if the expected object and the actual object are equal. If they
	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
	 * has a default String to identify itself.
	 * 
	 * @param expected
	 *            the object that is correct.
	 * @param actual
	 *            the object that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(Object expected, Object actual)
			throws AssertionFailedException {
		assertEquals(ASSERT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected object and the actual object aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * It has a default String to identify itself.
	 * 
	 * @param expected
	 *            the object that is correct.
	 * @param actual
	 *            the object that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(Object expected, Object actual)
			throws AssertionFailedException {
		assertNotEquals(ASSERT_NOT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected boolean and the actual boolean are equal. If they
	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
	 * has a default String to identify itself.
	 * 
	 * @param expected
	 *            the boolean that is correct.
	 * @param actual
	 *            the boolean that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(boolean expected, boolean actual)
			throws AssertionFailedException {
		assertEquals(ASSERT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected boolean and the actual boolean aren't equal. If
	 * they aren't, nothing happens. Otherwise, it throws a
	 * AssertionFailedException. It has a default String to identify itself.
	 * 
	 * @param expected
	 *            the boolean that is correct.
	 * @param actual
	 *            the boolean that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(boolean expected, boolean actual)
			throws AssertionFailedException {
		assertNotEquals(ASSERT_NOT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected char and the actual char are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
	 * a default String to identify itself.
	 * 
	 * @param expected
	 *            the char that is correct.
	 * @param actual
	 *            the char that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(char expected, char actual)
			throws AssertionFailedException {
		assertEquals(ASSERT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected char and the actual char aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * It has a default String to identify itself.
	 * 
	 * @param expected
	 *            the char that is correct.
	 * @param actual
	 *            the char that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(char expected, char actual)
			throws AssertionFailedException {
		assertNotEquals(ASSERT_NOT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected int and the actual int are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
	 * a default String to identify itself.
	 * 
	 * @param expected
	 *            the int that is correct.
	 * @param actual
	 *            the int that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(int expected, int actual)
			throws AssertionFailedException {
		assertEquals(ASSERT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected int and the actual int aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * It has a default String to identify itself.
	 * 
	 * @param expected
	 *            the int that is correct.
	 * @param actual
	 *            the int that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(int expected, int actual)
			throws AssertionFailedException {
		assertNotEquals(ASSERT_NOT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected byte and the actual byte are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
	 * a default String to identify itself.
	 * 
	 * @param expected
	 *            the byte that is correct.
	 * @param actual
	 *            the byte that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(byte expected, byte actual)
			throws AssertionFailedException {
		assertEquals(ASSERT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected byte and the actual byte aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * It has a default String to identify itself.
	 * 
	 * @param expected
	 *            the byte that is correct.
	 * @param actual
	 *            the byte that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(byte expected, byte actual)
			throws AssertionFailedException {
		assertNotEquals(ASSERT_NOT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected long and the actual long are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
	 * a default String to identify itself.
	 * 
	 * @param expected
	 *            the long that is correct.
	 * @param actual
	 *            the long that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(long expected, long actual)
			throws AssertionFailedException {
		assertEquals(ASSERT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected long and the actual long aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * It has a default String to identify itself.
	 * 
	 * @param expected
	 *            the long that is correct.
	 * @param actual
	 *            the long that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(long expected, long actual)
			throws AssertionFailedException {
		assertNotEquals(ASSERT_NOT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected short and the actual short are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
	 * a default String to identify itself.
	 * 
	 * @param expected
	 *            the short that is correct.
	 * @param actual
	 *            the short that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(short expected, short actual)
			throws AssertionFailedException {
		assertEquals(ASSERT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected short and the actual short aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * It has a default String to identify itself.
	 * 
	 * @param expected
	 *            the short that is correct.
	 * @param actual
	 *            the short that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(short expected, short actual)
			throws AssertionFailedException {
		assertNotEquals(ASSERT_NOT_EQUALS_FAILED, expected, actual);
	}

	//#ifdef DCLDCV11
	/**
	 * Assert if the expected float and the actual float are equal. If they are,
	 * nothing happens. Otherwise, it throws a AssertionFailedException. It has
	 * a default String to identify itself.
	 * 
	 * @param expected
	 *            the float that is correct.
	 * @param actual
	 *            the float that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(float expected, float actual)
			throws AssertionFailedException {
		assertEquals(ASSERT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected float and the actual float aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * It has a default String to identify itself.
	 * 
	 * @param expected
	 *            the float that is correct.
	 * @param actual
	 *            the float that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(float expected, float actual)
			throws AssertionFailedException {
		assertNotEquals(ASSERT_NOT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected double and the actual double are equal. If they
	 * are, nothing happens. Otherwise, it throws a AssertionFailedException. It
	 * has a default String to identify itself.
	 * 
	 * @param expected
	 *            the double that is correct.
	 * @param actual
	 *            the double that should be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertEquals(double expected, double actual)
			throws AssertionFailedException {
		assertEquals(ASSERT_EQUALS_FAILED, expected, actual);
	}

	/**
	 * Assert if the expected double and the actual double aren't equal. If they
	 * aren't, nothing happens. Otherwise, it throws a AssertionFailedException.
	 * It has a default String to identify itself.
	 * 
	 * @param expected
	 *            the double that is correct.
	 * @param actual
	 *            the double that shouldn't be correct.
	 * @throws AssertionFailedException
	 *             if the assertion fail.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		assertNotEquals(double expected, double actual)
			throws AssertionFailedException {
		assertNotEquals(ASSERT_NOT_EQUALS_FAILED, expected, actual);
	}
	//#endif

	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition. It receives some identification parameters, used by the
	 * framework in the console fail report.
	 * 
	 * @param test
	 *            the identification of what failed.
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail(String test) throws AssertionFailedException {
		throw new AssertionFailedException(test);
	}

	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition. It receives some identification parameters, used by the
	 * framework in the console fail report.
	 * 
	 * @param test
	 *            the identification of what failed.
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail(String test, short expected, short actual)
			throws AssertionFailedException {
		fail(test, new Short(expected), new Short(actual));
	}

	//#ifdef DCLDCV11
	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition. It receives some identification parameters, used by the
	 * framework in the console fail report.
	 * 
	 * @param test
	 *            the identification of what failed.
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail(String test, float expected, float actual)
			throws AssertionFailedException {
		fail(test, new Float(expected), new Float(actual));
	}

	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition. It receives some identification parameters, used by the
	 * framework in the console fail report.
	 * 
	 * @param test
	 *            the identification of what failed.
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail(String test, double expected, double actual)
			throws AssertionFailedException {
		fail(test, new Double(expected), new Double(actual));
	}
	//#endif

	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition. It receives some identification parameters, used by the
	 * framework in the console fail report.
	 * 
	 * @param test
	 *            the identification of what failed.
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail(String test, long expected, long actual)
			throws AssertionFailedException {
		fail(test, new Long(expected), new Long(actual));
	}

	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition. It receives some identification parameters, used by the
	 * framework in the console fail report.
	 * 
	 * @param test
	 *            the identification of what failed.
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail(String test, byte expected, byte actual)
			throws AssertionFailedException {
		fail(test, new Byte(expected), new Byte(actual));
	}

	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition. It receives some identification parameters, used by the
	 * framework in the console fail report.
	 * 
	 * @param test
	 *            the identification of what failed.
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail(String test, int expected, int actual)
			throws AssertionFailedException {
		fail(test, new Integer(expected), new Integer(actual));
	}

	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition. It receives some identification parameters, used by the
	 * framework in the console fail report.
	 * 
	 * @param test
	 *            the identification of what failed.
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail(String test, char expected, char actual)
			throws AssertionFailedException {
		fail(test, new Character(expected), new Character(actual));
	}

	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition. It receives some identification parameters, used by the
	 * framework in the console fail report.
	 * 
	 * @param test
	 *            the identification of what failed.
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail(String test, boolean expected, boolean actual)
			throws AssertionFailedException {
		fail(test, new Boolean(expected), new Boolean(actual));
	}

	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition. It receives some identification parameters, used by the
	 * framework in the console fail report.
	 * 
	 * @param test
	 *            the identification of what failed.
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail(String test, Object expected, Object actual)
			throws AssertionFailedException {
		if (test == null) {
			test = "";
		} else {
			test = test.trim();
			if (!test.endsWith(".")) {
				test = test + ".";
			}
		}
		String message = test + " Expected " + expected + ", but was " + actual
				+ ".";
		fail(message);
	}

	/**
	 * This method is used to notify the framework that a assertion failed. It
	 * also may be used by the developers to produce a fail in some special
	 * condition.
	 * 
	 * @throws AssertionFailedException
	 *             as result of a failed assertion.
	 * @since JMUnit 1.0
	 */
	//#ifdef DJMTESTPLUS
//@	public final void
	//#else
	public static final void
	//#endif
		fail() throws AssertionFailedException {
		fail(null);
	}

}

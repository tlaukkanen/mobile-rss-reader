/*
 * RecStoreLoggerMIDlet.java
 *
 * Copyright (C) 2007 Irving Bunton
 * http://code.google.com/p/jlogmicro/source
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * Alternately, at your option, you can redistribute the software and/or modify
 * it under the terms the GNU Lessor General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License or
 * GNU Lesser Public License
 * along with this program; if not, write to the Free Software Foundation, Inc.,
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
/*
 * IB 2010-07-10 1.1Alpha4 Add LGPL V2.1 and later as an option as a license choice in addition to GPL.
 * IB 2010-07-10 1.1Alpha4 Update source text to make distribution/redistribution license options clearer.
 */
// Expand to define CLDC define
//#define DCLDC11
// Expand to define logging define
//#define DLOGGING
//#ifdef DLOGGING
package net.sf.jlogmicro.util.presentation;

import java.util.Enumeration;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.UnsupportedEncodingException;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;

import net.sf.jlogmicro.util.logging.Logger;
import net.sf.jlogmicro.util.logging.RecStoreHandler;
import net.sf.jlogmicro.util.logging.BufferedHandler;
import net.sf.jlogmicro.util.logging.Handler;
import net.sf.jlogmicro.util.logging.LogManager;
import net.sf.jlogmicro.util.logging.Level;
import net.sf.jlogmicro.util.presentation.RecStoreLoggerForm;

public class RecStoreLoggerMIDlet extends MIDlet {
    private boolean fineLoggable = false;
    private boolean finestLoggable = false;
    private Logger logger = null;
    private Form logf;

	public RecStoreLoggerMIDlet() {
		super();
		final LogManager logManager = LogManager.getLogManager();
        logManager.readConfiguration(this);
        logger = Logger.getLogger(logManager, "RecStoreLoggerMIDlet", null);
        try {
            fineLoggable = logger.isLoggable(Level.FINE);
            finestLoggable = logger.isLoggable(Level.FINEST);
			logf = new RecStoreLoggerForm(logManager, this, null);
			logf.setCommandListener((CommandListener)logf);
        } catch (Throwable e) {
            logger.severe("RecStoreLoggerMIDlet " + e.getMessage(), e);
        }

	}

    public void startApp() {
		try {
			logger.info("Test info.");
			logger.fine("Test fine.");
			logger.finer("Test finer.");
			logger.finest("Test finest.");
			logger.trace("Test trace.");
			Alert m_about = getAbout();
			Display.getDisplay(this).setCurrent(m_about, logf);
		} catch (Throwable e) {
			System.out.println("publish " + e.getClass().getName() + " " 
					+ e.getMessage());
			e.printStackTrace();
		}
	}

    public void pauseApp() {}
    public void destroyApp(boolean unconditional) {}

    /**
	 * Create about alert.
	 * @author  Irving Bunton
	 * @version 1.0
	 */
	private Alert getAbout() {
		Alert about = new Alert("About RssReader",
"JLogMicro v@MIDLETVERS@ " +
 "Copyright (C) 2007 Irving Bunton " +
 " http://code.google.com/p/jlogmicro/source " +
 "This program is distributed in the hope that it will be useful, " +
 "but WITHOUT ANY WARRANTY; without even the implied warranty of " +
 "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the " +
 "GNU General Public License for more details. " +
 "This program is free software; you can redistribute it and/or modify " +
 "it under the terms of the GNU General Public License as published by " +
 "the Free Software Foundation; either version 2 of the License, or " +
 "(at your option) any later version.  ", null, AlertType.INFO);
		about.setTimeout(Alert.FOREVER);
 
		return about;
	}

}
//#endif

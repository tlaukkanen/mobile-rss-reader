/*
 * ResourceProviderME.java
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

// Expand to define MIDP define
//#define DMIDP10

//#ifdef DMIDP20
//@
//@package cz.cacek.ebook;
//@
//@import java.io.IOException;
//@import java.util.Hashtable;
//@
//@/**
//@ * Holds translations for EBookME - list of resources is generated in ResourceProvider class
//@ * in packager application.
//@ * @author Josef Cacek [josef.cacek (at) atlas.cz]
//@ * @author $Author: kwart $
//@ * @version $Revision: 1.4 $
//@ * @created $Date: 2006/03/20 15:21:22 $
//@
//@ */
//@public final class ResourceProviderME {
//@
//@	/**
//@	 * singleton instance of ResourceProvider
//@	 */
//@	public static final ResourceProviderME provider = new ResourceProviderME();
//@	
//@	private Hashtable messages;
//@	
//@	private ResourceProviderME() {
//@		super();		
//@		final Hashtable tmpMsgs = new Hashtable();
//@		try {
//@            UTF8ISReader tmpReader = new UTF8ISReader(getClass().getResourceAsStream(
//@                    "/"+Common.DATA_FOLDER+"/" + Common.LANGUAGE_FILE));
//@    		char tmpChr[] = new char[1];
//@    		StringBuffer tmpSB[] = new StringBuffer[2];
//@    		tmpSB[0] = new StringBuffer();
//@    		tmpSB[1] = new StringBuffer();
//@    		int tmpPos = 0;
//@            boolean tmpBSlash = false;
//@    		while (1 == tmpReader.read(tmpChr)) {
//@    			switch (tmpChr[0]) {
//@    				case '\n' : 
//@    					tmpPos = 0;
//@    					tmpMsgs.put(tmpSB[0].toString(), tmpSB[1].toString());
//@    					tmpSB[0].setLength(0);
//@    					tmpSB[1].setLength(0);
//@                        tmpBSlash = false;
//@    					break;
//@    				case '=' : 
//@    					tmpPos = 1;
//@    					break;
//@                    case '\\':
//@                        if (tmpBSlash) {
//@                            tmpSB[tmpPos].append('\\');
//@                        } else {
//@                            tmpBSlash = true;
//@                        }
//@                        break;
//@                    case 'n':
//@                        if (tmpBSlash) {
//@                            tmpBSlash = false;
//@                            tmpSB[tmpPos].append('\n');
//@                            break;
//@                        } 
//@                    default:
//@                        if (tmpBSlash) {
//@                            tmpSB[tmpPos].append('\\');
//@                            tmpBSlash = false;
//@                        }
//@    					tmpSB[tmpPos].append(tmpChr[0]);
//@    					break;
//@    			}
//@    		}
//@            tmpReader.close();
//@            setMessages(tmpMsgs);
//@		} catch (IOException ioe) {
//@			throw new RuntimeException(ioe.getMessage());
//@        }
//@	}
//@
//@	/**
//@	 * Returns message identified by given key.
//@	 * @param aKey
//@	 * @return message identified by given key
//@	 */
//@	public synchronized static String get(final String aKey) {
//@		final String tmpResult = (String) provider.getMessages().get(aKey);
//@		if (tmpResult == null) {
//@			return aKey;
//@		}
//@		return tmpResult;
//@	}
//@	
//@    public synchronized Hashtable getMessages() {
//@        return messages;
//@    }
//@    
//@    private synchronized void setMessages(final Hashtable aMsgs) {
//@        messages = aMsgs;
//@    }
//@}
//#endif

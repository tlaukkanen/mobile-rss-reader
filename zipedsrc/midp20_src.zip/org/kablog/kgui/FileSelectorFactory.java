/* From kablog-j2me. */
package org.kablog.kgui;

public class FileSelectorFactory {

	//#ifdef JSR75
//@	public static KFileSelector getInstance() {
//@		
//@		KFileSelector newInst = null;
//@		
//@		newInst = new KFileSelectorImpl();
//@		
//@		return newInst;
//@	}
	//#endif
}

/*
 * LoadingForm.java
 *
 * Copyright (C) 2005-2006 Tommi Laukkanen
 * http://code.google.com/p/mobile-rss-reader/
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

// Expand to define MIDP define
//#define DMIDP20
// Expand to define test define
//#define DTEST
// Expand to define test ui define
//#define DTESTUI
// Expand to define logging define
//#define DLOGGING

package com.substanceofcode.rssreader.presentation;

import java.util.Hashtable;

import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;

//#ifdef DLOGGING
import net.sf.jlogmicro.util.logging.Logger;
import net.sf.jlogmicro.util.logging.LogManager;
import net.sf.jlogmicro.util.logging.Level;
//#endif

/* Form to show data being loaded.  Save messages and exceptions to
   allow them to be viewed separately as well as diagnostics for
   reporting errors. */
final public class LoadingForm extends Form implements CommandListener {
	//#ifdef DMIDP10
//@	private String      m_title;         // Store title.
	//#endif
	private Command     m_loadBackCmd;   // The load form back to prev displayable command
	private Command     m_loadMsgsCmd;   // The load form messages command
	private Command     m_loadDiagCmd;   // The load form diagnostic command
	private Command     m_loadErrCmd;    // The load form error command
	private Vector m_msgs = new Vector(); // Original messages
	private Vector m_excs = new Vector(); // Only errors
	private Displayable m_disp;

	/* Constructor */
	public LoadingForm(final String title, final Displayable disp) {
		super(title);
		//#ifdef DMIDP10
//@		this.m_title = title;
		//#endif
		m_loadMsgsCmd       = new Command("Messages", Command.SCREEN, 1);
		m_loadErrCmd        = new Command("Errors", Command.SCREEN, 2);
		m_loadDiagCmd       = new Command("Diagnostics", Command.SCREEN, 3);
		m_loadBackCmd       = new Command("Back", Command.BACK, 4);
		super.addCommand( m_loadMsgsCmd );
		super.addCommand( m_loadErrCmd );
		super.addCommand( m_loadDiagCmd );
		m_disp = disp;
		if (disp != null) {
			super.addCommand( m_loadBackCmd);
		}
		super.setCommandListener( this );
	}

	/** Respond to commands */
	public void commandAction(final Command c, final Displayable s) {
		//#ifdef DTESTUI
		super.outputCmdAct(c, s);
		//#endif

		if( c == m_loadBackCmd ){
			setCurrent( m_disp );
		}

		/** Give messages for loading */
		if( c == m_loadMsgsCmd ) {
			showMsgs();
		}

		/** Give errors for loading */
		if( c == m_loadErrCmd ) {
			showErrMsgs(true);
		}

		/** Give diagnostics for loading */
		if( c == m_loadDiagCmd ) {
			showErrMsgs(false);
		}

	}
	/* Show errors and diagnostics. */
	final private void showMsgs() {
		try {
			while(super.size()>0) {
				super.delete(0);
			}
			final int elen = m_msgs.size();
			for (int ic = 0; ic < elen; ic++) {
				super.append((String)m_msgs.elementAt(ic));
			}
		}catch(Throwable t) {
			//#ifdef DLOGGING
			logger.severe("showMsgs", t);
			//#endif
			/** Error while executing constructor */
			System.out.println("showMsgs " + t.getMessage());
			t.printStackTrace();
		}
	}

	/* Show errors and diagnostics. */
	final private void showErrMsgs(final boolean showErrsOnly) {
		try {
			while(super.size()>0) {
				super.delete(0);
			}
			final int elen = m_excs.size();
			for (int ic = 0; ic < elen; ic++) {
				Throwable nexc = (Throwable)m_excs.elementAt(ic);
				while (nexc != null) {
					String msg = nexc.getMessage();
					if (msg != null) {
						super.append(nexc.getMessage());
						// If showing errs only, only show the first error found
						if (showErrsOnly) {
							break;
						}
					} else if (!showErrsOnly) {
						super.append("Error " + nexc.getClass().getName());
					}
					if (nexc instanceof CauseException) {
						nexc = ((CauseException)nexc).getCause();
					} else {
						break;
					}
				}
			}
			if (!showErrsOnly) {
				super.append(new StringItem("Active Threads:",
							Integer.toString(Thread.activeCount())));
			}
		}catch(Throwable t) {
			//#ifdef DLOGGING
			logger.severe("showErrMsgs", t);
			//#endif
			/** Error while executing constructor */
			System.out.println("showErrMsgs " + t.getMessage());
			t.printStackTrace();
		}
	}

	/* Append message to form and save in messages. */
	final public void appendMsg(final String msg) {
		if (msg != null) {
			super.append(msg);
			m_msgs.addElement(msg);
		}
	}

	/* Add exception. */
	final public void addExc(final Throwable exc) {
		m_excs.addElement(exc);
	}

	/* Remove reference to displayable to free memory. */
	final public void removeRef(final Displayable disp) {
		synchronized (this) {
			if (m_disp == disp) {
				m_disp = m_bookmarkList;
				//#ifdef DLOGGING
				if (finestLoggable) {logger.finest("Ref removed " + disp);}
				//#endif
			}
		}
	}

	//#ifdef DMIDP10
//@	public String getTitle() {
//@		return m_title;
//@	}
	//#endif

}
